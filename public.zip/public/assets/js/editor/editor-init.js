import { createEditor } from './tiptap-setup.js'

document.addEventListener('DOMContentLoaded', () => {
  const editorContainer = document.querySelector('#editor')

  if (editorContainer) {
    // Optional: JSON-Inhalt laden (z. B. aus data-Attribut oder API)
    const initialContent = editorContainer.dataset.content || '<p>Neues Dokument</p>'
    createEditor('#editor', initialContent)
  }
})

import { createEditor } from './tiptap-setup.js'

let editor = null
let saveTimeout = null

document.addEventListener('DOMContentLoaded', () => {
  const editorContainer = document.querySelector('#editor')
  const textDocumentId = editorContainer.dataset.id
  const initialContent = editorContainer.dataset.content

  if (!editorContainer || !textDocumentId) {
    console.error('Editor oder TextDocument-ID fehlt.')
    return
  }

  editor = createEditor('#editor', initialContent)

  editor.on('update', () => {
    if (saveTimeout) clearTimeout(saveTimeout)

    saveTimeout = setTimeout(() => {
      const jsonContent = editor.getJSON()

      fetch(`/api/textdocument/${textDocumentId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ content: jsonContent }),
      })
        .then(response => {
          if (!response.ok) {
            console.error('Fehler beim Speichern')
          }
        })
        .catch(error => {
          console.error('Netzwerkfehler:', error)
        })
    }, 3000)
  })
})
